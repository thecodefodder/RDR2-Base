#ifndef _MAIN_HPP
#define _MAIN_HPP

#include <common.hpp>

class Main {
public:
    bool running = true;
};
inline Main g_Main;

#endif